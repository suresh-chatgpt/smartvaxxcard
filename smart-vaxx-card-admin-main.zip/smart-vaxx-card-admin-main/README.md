# smart-vaxx-card-admin
Admin portal for Smart Vaxx Card Project
### Features:
- email authentication
- manage covid vaccination centers' data

### Tech Stack:
- React Typescript
- Firebase

Works on all browsers and is mobile responsive :smile:
